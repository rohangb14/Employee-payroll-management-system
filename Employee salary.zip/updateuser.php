<?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "employee";
            $conn = mysqli_connect($servername,$username,$password,$dbname );
            error_reporting(0);
            
            

                $empid=$_GET['empid'];
                $fname=$_GET['fname'];
                $lname=$_GET['lname'];
               
                $dob=$_GET['dob'];
                $doj=$_GET['doj'];
                $address=$_GET['address'];
                $mobile=$_GET['mobile'];

                $gender=$_GET['gender'];
                $designation=$_GET['designation'];
                $accountno=$_GET['accountno'];
                $adhar=$_GET['adhar'];
                $pan=$_GET['pan'];
                $deptid=$_GET['deptid'];

                // UPDATE REGISTRIEES SET NAME='$N',USN='$U',YEAR='$Y',PHONENUMBER='$P',EMAIL='$E',ADDRESS='$A',PROJECT='$PR' WHERE USN='$U';

            $query=" UPDATE employee set empid='$empid', fname='$fname',lname='$lname',dob='$dob',doj='$doj',address='$address',mobile='$mobile', 
            gender='$gender', designation='$designation',accountno='$accountno',adhar='$adhar',pan='$pan',deptid='$deptid' WHERE empid='$empid'; ";
                $data=mysqli_query($conn,$query);
                if($data){
                   

                    echo '<script type="text/javascript"> alert(" Updated!"); </script>';
                    echo '<a href="index.php" ><button style="width:50px;height:50px;">View</button></a>';
                    
                    
            
                    
             }else{
                    echo '<script type="text/javascript"> alert(" NOt Updated!"); </script>';
                }

            
            
            
            ?>
            