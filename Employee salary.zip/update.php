<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";
$conn = mysqli_connect($servername,$username,$password,$dbname );
error_reporting(0);





?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">+
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- Bootstrap CSS CDN -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


</head>

  <style>{box-sizing: border-box}

/* Add padding to containers */
.container {
  padding: 10px;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 8px 0 12px 0;
  display: inline-block;
  border: none;
  background: #e6ecff;
  font-size:15px;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit/register button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity:1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
.container {
  padding: 15px;
  margin: 30px 0 10px 0;
  font-family: monospace;
  font-size: 15px;
}
</style>
   
   <title>NEW USER</title>
</head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
 <body>


 <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Employee Database</h3>
                <strong>ED</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-user-circle"></i>
                        User
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="newuser.php">Add New Employee</a>
                        </li>
                        <li>
                            <a href="viewuser.php"> View Employee</a>
                        </li>
                        <li>
                            <a href="salary.php">Add Salary</a>
                        </li>
                    
                        <li>
                            <a href="viewsalary.php">View Salary</a>
                        </li>
                    
                    </ul>
                </li>
                <li>
                   
                    </a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-copy"></i>
                        Department
                    </a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="research.html">Research department</a>
                        </li>
                        <li>
                            <a href="account.html">Accounts Department</a>
                        </li>
                        <li>
                            <a href="#"> </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-image"></i>
                        Portfolio.   
                    </a>
                </li>
                <!-- <li>
                    <a href="#">
                        <i class="fas fa-question"></i> 
                        FAQ
                    </a>
                </li> -->
                <li>
                    <a href="#">
                        <i class="fas fa-paper-plane"></i>
                        Contact
                    </a>
                </li>
            </ul>

          
        </nav>
        <div id="content">
             
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                       
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <!-- <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i> -->

                      </nav>


  
<form action="updateuser.php" method="GET">

  <div class="container">
    <h1>NEW USER</h1>
    <p>Fill the Details of Emmployee</p>
    <hr>

    <label for="empid"> <b>Employee ID</b></label>
    <input type="text" value="<?php echo $_GET['empid'] ?>" placeholder="Employee id" name="empid" required>

    <label for="name"><b>First Name</b></label>
    <input type="text" value="<?php echo $_GET['fname'] ?>"  placeholder="First Name" name="fname" required>
    
    <label for="name"><b>Last Name</b></label>
    <input type="text" value="<?php echo $_GET['lname'] ?>"  placeholder="Last Name" name="lname" required>
    

    <label for="name"><b>Gender</b></label>
    <input type="text"value="<?php echo $_GET['gender'] ?>"  placeholder="gender" name="gender" required>

    <label for="dob"><b>Date Of Birth</b></label><br>
    <input type="date" value="<?php echo $_GET['dob'] ?>" placeholder="DATE OF BIRTH" name="dob" required><br>

     <br><label for="doj"><b>Date Of Join</b></label><br>
    <input type="date" value="<?php echo $_GET['doj'] ?>"  placeholder="Date of join" name="doj" required><br>

     <br><label for="address"><b>Address</b></label><br>
    <input type="text" value="<?php echo $_GET['address'] ?>"  placeholder="address" name="address" required>
    
    <label for="mobile"><b>Mobile Number</b></label>
    <input type="text" value="<?php echo $_GET['mobile'] ?>" placeholder="mobile" name="mobile" required>
    
    <label for="designation"><b>Designation</b></label>
     <input type="text"value="<?php echo $_GET['designation'] ?>"  placeholder="designation" name="designation" required>

    <label for="name"><b>Bank Account Number</b></label>
    <input type="text"value="<?php echo $_GET['accountno'] ?>"  placeholder="Bank account" name="accountno" required>

    <label for="name"><b>Adhar card number</b></label>
    <input type="text"value="<?php echo $_GET['adhar'] ?>"  placeholder="adhar card number" name="adhar" required>
    
    <label for="name"><b>Pan number</b></label>
    <input type="text" value="<?php echo $_GET['pan'] ?>" placeholder="pan number" name="pan" required>

     

    <label for="deptid"><b>Depatment ID</b></label>

    

<select class="form-control" name="deptid" id="inputState">

<option selected>choose</option>
<?php 
    $query="SELECT * FROM DEPARTMENT";
    $data=mysqli_query($conn,$query);
    $cnt=1;

    while($result= mysqli_fetch_assoc($data)){

      ?>


<option ><?php echo $result['deptid']; ?></option>

<?php
  $cnt++;
}
    ?>

</select>


     



    

      <button type="submit" value="update" class="registerbtn">submit</button>
   </div>


  </form>

  

</body>
</html>