<?php
    session_start();
    if($_SESSION['lod2']==0){
        echo "<script>alert('Currently Logged out');</script>";
        header("Location: homepage.php");
    }
?>