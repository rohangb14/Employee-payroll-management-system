<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";
$op="";
$conn = mysqli_connect($servername,$username,$password,$dbname );
//error_reporting(0);
//if(isset($_POST['empid']))
$id=$_POST['empid'];

$query=" SELECT e.empid,e.fname,e.lname,s.bsalary,s.hra,s.sa,s.bonous,s.da,s.inscentive,s.tsalary,d.pfund,d.incometax,d.ar,d.ptax, d.finalsalary from employee e,salary s,deduction d where e.empid like '%$id%' and s.empid=d.empid and d.empid=e.empid";
$data=mysqli_query($conn,$query);
$total=mysqli_num_rows($data);


if($total==0){

    echo '<script type="text/javascript"> alert(" NO RECORDS FOUND!!"); </script>';
}


?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Employee Database</title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
  
    <style>
  

        
        .col-sm-2{
        
        margin:20px;
        height:350px;
        width: 200px;;
        text-align: center;
        display: flex;
        justify-content: center;
            flex-direction: column;
        overflow: hidden;
        
        }
      
        
        .col-sm-2{
        
        margin:20px;
        height:350px;
        width: 200px;;
        text-align: center;
        display: flex;
        justify-content: center;
            flex-direction: column;
        overflow: hidden;
        
        }
        #content{
            font-family: monospace;
        }
       

    </style>

</head>
<body>
<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Employee Database</h3>
                <strong>ED</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-user-circle"></i>
                        User
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="newuser.php">  New Employee</a>
                        </li>
                        <li>
                            <a href="viewuser1.php"> View Employee</a>
                        </li>
                        <li>
                            <a href="salary.php">Add Salary</a>
                        </li>
                    
                        <li>
                            <a href="viewsalary.php">View Salary</a>
                        </li>
                    
                    </ul>
                </li>
                <li>
                   
                    </a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-copy"></i>
                        Department
                    </a>
                     <ul class="collapse list-unstyled" id="pageSubmenu"> 
                        <li>
                            <a href="research.php">Research department</a>
                        </li>
                        <li>
                            <a href="resource.php">Marketing Department</a>
                        </li>
                        <li>
                            <a href="finance.php">Finance Department </a>
                        </li>
                    </ul>
                </li>
                <li>
                     <a href="searchicon.php">
                        <i class="fas fa-search"></i>
                        Search   
                    </a>
                </li> 
              
            </ul>

          
        </nav>

        <!-- Page Content  -->
            
        
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                       
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>

                      </nav>

                      <div class="wrapper d-flex justify-content-between" >
    <div id="content">
     <div class="container-fluid" align="center" style="margin-top:1%;">
                <h1>SEARCHED RESULT</h1><br>
              
      
             </div>
      
              <table class="table table-stripped" style="width:80%;font-size:15px;font-weight:100; margin-left:10%;" >
        <thead>
        <tr>
        
<th>Employee ID</th>
<th>First Name</th>
<th>Last Name</th>
<th>Basic Salary</th>
<th>House Rent Allowance</th>
<th>Special Allowance</th>
<th>Bonus</th>
<th>Inscentive</th>
<th>Dear Allowance</th>
<th>Provident Fund</th>
<th>Income Tax</th>
<th>Advance Recovery</th>
<th>Professional Tax</th>
<th>Final Salary</th>

<?php if($id!=""){ ?>
        
      </tr>
        </thead>
        <tbody>
          <tr>
              <?php
              
              $data=mysqli_query($conn,$query);
              $cnt=1;

              while( $result= mysqli_fetch_array($data)){

             ?>
            
            <td><?php  echo $result['empid'] ?></td>
            <td><?php  echo $result['fname'] ?></td>
            <td><?php  echo $result['lname']  ?></td>
            <td><?php  echo $result['bsalary']  ?></td>
            <td><?php  echo $result['hra']  ?></td>
            <td><?php  echo $result['sa']  ?></td>
            <td><?php  echo $result['bonous']  ?></td>
            <td><?php  echo $result['inscentive'] ?></td>
            <td><?php  echo $result['da']  ?></td>
            <td><?php  echo $result['pfund']  ?></td>
            <td><?php  echo $result['incometax']  ?></td>
            <td><?php  echo $result['ar']  ?></td>
            <td><?php  echo $result['ptax']  ?></td>
            <td><?php  echo $result['finalsalary'] ?></td>
            <?php $result= mysqli_fetch_array($data); ?>
        <?php } ?>
        </tbody>
              </table>

             </div>

              <?php } ?>
</body>
</html>