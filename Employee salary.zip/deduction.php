<?php 
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";
$ar=1000;
$ptax=2000;
$incometax= _POST['incometax'];
$ptax=_POST['ptax'];




$tdeduction=$pfund+$incometax+$ar+$ptax;



//create connection

$conn = new mysqli($servername,$username,$password,$dbname );

$query="SELECT pfund,incometax,ar,ptx ('$pfund'+'$incometax'+'$ar',+'$ptax') as tdeduction ");

$data1=mysqli_query($conn,$query);

?>