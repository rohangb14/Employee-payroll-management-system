<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";
$conn = mysqli_connect($servername,$username,$password,$dbname );
error_reporting(0);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Employee Database</title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
  
    <style>
  

        }
        .col-sm-2{
        
        margin:20px;
        height:350px;
        width: 200px;;
        text-align: center;
        display: flex;
        justify-content: center;
            flex-direction: column;
        overflow: hidden;
        
        }
      
        }
        .col-sm-2{
        
        margin:20px;
        height:350px;
        width: 200px;;
        text-align: center;
        display: flex;
        justify-content: center;
            flex-direction: column;
        overflow: hidden;
        
        }
        @import url(https://fonts.googleapis.com/css?family=Open+Sans);

body{
  background: #f2f2f2;
  font-family: 'Open Sans', sans-serif;
}

.search {
  width: 100%;
  position: center;
  display: flex;
  
}

.searchTerm {
  width: 100%;
  border: 3px solid #00B4CC;
  border-right: none;
  padding: 15px;
  height: 50px;
  border-radius: 5px 0 0 5px;
  outline: none;
  color: #9DBFAF;
  
}

.searchTerm:focus{
  color: #00B4CC;
  
}

.searchButton {
  width: 50px;
  height: 50px;
  border: 1px solid #00B4CC;
  background: #00B4CC;
  text-align: center;
  color: #fff;
  border-radius: 0 5px 5px 0;
  cursor: pointer;
  font-size: 30px;
}

/*Resize the wrap to see the search bar change!*/
.wrap{
  width:70%;
  position: absolute;
  top: 30%;
  left: 58%;
  transform: translate(-50%, -50%);
}
       
       
    </style>

</head>
<body>
<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Employee Database</h3>
                <strong>ED</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-user-circle"></i>
                        User
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="newuser.php">Add New Employee</a>
                        </li>
                        <li>
                            <a href="viewuser1.php"> View Employee</a>
                        </li>
                        <li>
                            <a href="salary.php">Add Salary</a>
                        </li>
                    
                        <li>
                            <a href="viewsalary.php">View Salary</a>
                        </li>
                    
                    </ul>
                </li>
                <li>
                   
                    </a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-copy"></i>
                        Department
                    </a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="research.php">Research department</a>
                        </li>
                        <li>
                            <a href="resource.php">Resource Department</a>
                        </li>
                        <li>
                            <a href="finance.php">Finance Department </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">
                        <i class="fas fa-image"></i>
                        Portfolio.   
                    </a>
                </li>
                <!-- <li>
                    <a href="#">
                        <i class="fas fa-question"></i> 
                        FAQ
                    </a>
                </li> -->
                <li>
                    <a href="#">
                        <i class="fas fa-paper-plane"></i>
                        Contact
                    </a>
                </li>
            </ul>

          
        </nav>

        <!-- Page Content  -->
            
        
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                       
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>

                      </nav>
                      <div class="wrapper d-flex justify-content-between" >
    <div id="content">
     <div class="container-fluid" align="center" style="margin-top:1%;">
                <h1>SEARCH EMPLOYEE DETAILS </h1><br>
             </div>
             <div class="wrap">
   <form class="search" method="post" action="search.php">
      <input type="text" class="searchTerm" name="empid" placeholder="Enter Employee ID">
      <button type="submit" class="searchButton">
        <i class="fa fa-search"></i>
     </button>
   </form>
</div>