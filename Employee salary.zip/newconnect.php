<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";
$id = $_POST['empid'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$dob = $_POST['dob'];
$doj = $_POST['doj'];
$address = $_POST['address'];
$mobile = $_POST['mobile'];
$gender = $_POST['gender'];
$designation = $_POST['designation'];
$accountno = $_POST['accountno'];
$adhar = $_POST['adhar'];
$pan = $_POST['pan'];
$deptid = $_POST['deptid'];






//create connection

$conn = new mysqli($servername,$username,$password,$dbname );


//check connection

if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//insert into table
$sql = "INSERT INTO employee(empid,fname,lname,dob,doj,address,mobile,gender,designation,accountno,adhar,pan,deptid) VALUES ('$id','$fname','$lname','$dob','$doj','$address','$mobile','$gender','$designation','$accountno','$adhar','$pan','$deptid')";

if($conn->query($sql) === TRUE)
{
	$last_id = $conn->insert_id;
	echo '<script type="text/javascript"> alert(" EMPLOYEE SUCESSFULLY REGISTERED"); </script>';
}
else
{
	echo "Error:" . $sql . "<br>" . $conn->error;
}
header("refresh:2; url=index.php"); // url for wherever you want to direct it ! after login 
?>
