

<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";
$conn = mysqli_connect($servername,$username,$password,$dbname );
error_reporting(0);
$query=" SELECT * FROM EMPLOYEE";
$data=mysqli_query($conn,$query);
$total=mysqli_num_rows($data);
 $sex=$_GET['gender'];


if($total !=0)
{
    
   
}else{
 
   
    
}




?>




<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Employee Database</title>


    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


</head>
<style>

.col-sm-2{
        
        margin:15px;
        height:350px;
        width: 100px;;
        text-align: auto;
        display: flex;
        justify-content: center;
        flex-direction: column;
        overflow: hidden;
        border-radius:10px;
        transition:0.2s;
        background: #000;
        
        
        }
        .col-sm-2:hover{

box-shadow: 5px 5px 5px #83208c ;
margin:10px;
height:310px;
 width: 160px;

}

        #avat{
            height: 210px;
            background: none;
            border-radius: 50%;
            margin-top:40px;
            
            
        }
        #profcardname{
            font-family: monospace;
            font-weight: 900;
            font-size:1.6em;
        
        }
        #profcardUSN{
            font-size: 1.2em;
            font-weight: 600;
        }
        #profcardYear{
            font-size:1.15em;
            font-weight: 600;
        }


</style>
<body>
    
    <?php
        if($_SESSION['lod']=="out"){
            $_SESSION['lod2']=0;
            header("Location: lo_msg.php");
        }
    ?>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Employee Database</h3>
                <strong>ED</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-user-circle"></i>
                        User
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="newuser.php">  New Employee</a>
                        </li>
                        <li>
                            <a href="viewuser1.php"> View Employee</a>
                        </li>
                        <li>
                            <a href="salary.php">Add Salary</a>
                        </li>
                    
                        <li>
                            <a href="viewsalary.php">View Salary</a>
                        </li>
                    
                    </ul>
                </li>
                <li>
                   
                    </a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-copy"></i>
                        Department
                    </a>
                     <ul class="collapse list-unstyled" id="pageSubmenu"> 
                        <li>
                            <a href="research.php">Research department</a>
                        </li>
                        <li>
                            <a href="resource.php">Marketing Department</a>
                        </li>
                        <li>
                            <a href="finance.php">Finance Department </a>
                        </li>
                    </ul>
                </li>
                <li>
                     <a href="searchicon.php">
                        <i class="fas fa-search"></i>
                        Search   
                    </a>
                </li> 
              
            </ul>

          
        </nav>

        <!-- Page Content  -->
            
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button"  class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                       
                    </button>

                    <input type="submit" name="logout" value="Log Out" onclick="lo()"> </input>
                        <!-- <i class="fas fa-align-left"></i>  -->

                      </nav>



        


                      <div class="container-fluid" align="center">
                <h1>Our Community</h1>
               
                <div class="row" style="display:flex;justify-content:center;">



                <?php
              $data=mysqli_query($conn,$query);
              $cnt=1;

              while( $result= mysqli_fetch_assoc($data)){

                ?>


                  <div class="col-sm-2" style="background-color:#d1f1ff;">
                   
                  

                        
                  <div class="avatar" style="margin-top:-60px;">

             
                <!-- <img id="avat" src="imgs/avatar-boy-1.png" alt=""> -->

                <?php 
               
                            

                              
    
                            if( $result['gender']=='m'){
                               
                                echo '<img id="avat"  style="tranform:translateY(-270px);" src="boypng.png" >';

                            }else{

                                echo '<img id="avat"  style="margin-top:-20px;" src="girlpng.png" >';
                            }
  

                        
                        
                        
                ?>
                    
                     
                  </div>
                 

                 <span id="profcardname" style="z-index:1;" ><?php  echo $result['fname'] ?> <?php  echo $result['lname'] ?></span>
                
                 <span id="profcardUSN"><?php  echo $result['empid']  ?></span>
                 <br>
                 
                
                </div>

              
                 
                  <?php

            $cnt++;

                    } ?>

                  </div>
                                 
                </div>
              </div>
              
           
        </div>

          
        </div>
        

       
        

    </div>

   

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>

</html>

<script>
 function lo(){
     window.open("logout.php", "_self");
 }
</script>