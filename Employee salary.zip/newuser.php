<?php




$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";

error_reporting(0);

//create connection

$conn = new mysqli($servername,$username,$password,$dbname );

  $query="SELECT * FROM DEPARTMENT";

  $data=mysqli_query($conn,$query);
  $total=mysqli_num_rows($data);

  if($total != 0){
   
  }else{
    echo '<script type="text/javascript"> alert("");</script>';
  }


?>







<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Employee Database</title>
    <style>{box-sizing: border-box}

/* Add padding to containers */
.container {
  padding: 15px;
  margin: 30px 0 10px 0;
  font-family: monospace;
  font-size: 15px;
    
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 10px;
  margin: 8px 0 12px 0;
  display: inline-block;
  border: none;
  background: #e6ecff;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit/register button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity:1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

</head>

<body>
<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Employee Database</h3>
                <strong>ED</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-user-circle"></i>
                        User
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="newuser.php">  New Employee</a>
                        </li>
                        <li>
                            <a href="viewuser1.php"> View Employee</a>
                        </li>
                        <li>
                            <a href="salary.php">Add Salary</a>
                        </li>
                    
                        <li>
                            <a href="viewsalary.php">View Salary</a>
                        </li>
                    
                    </ul>
                </li>
                <li>
                   
                    </a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-copy"></i>
                        Department
                    </a>
                     <ul class="collapse list-unstyled" id="pageSubmenu"> 
                        <li>
                            <a href="research.php">Research department</a>
                        </li>
                        <li>
                            <a href="resource.php">Marketing Department</a>
                        </li>
                        <li>
                            <a href="finance.php">Finance Department </a>
                        </li>
                    </ul>
                </li>
                <li>
                     <a href="searchicon.php">
                        <i class="fas fa-search"></i>
                        Search   
                    </a>
                </li> 
              
            </ul>

          
        </nav>

        <!-- Page Content  -->
            
        
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                       
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>

                      </nav>





     <form action="newconnect.php" method="post" >
  <div class="container">
    <h1>Add New Employee </h1>
    <p>Fill the Details of Emmployee</p>
    <hr>

    <label for="empid"> <b>Employee ID</b></label>
    <input type="text" placeholder="Employee id" name="empid" required>
    
    <!-- <label for="name"><b>Employee Type</b></label>
    <input type="text" placeholder="Employee Type" name="etype" required>
     -->

    <label for="name"><b>First Name</b></label>
    <input type="text" placeholder="First Name" name="fname" required>
    
    <label for="name"><b>Last Name</b></label>
    <input type="text" placeholder="Last Name" name="lname" required>
    

    <label for="name"><b>Gender</b></label>
    <input type="text" placeholder="gender" name="gender" required>

    <label for="dob"><b>Date Of Birth</b></label><br>
    <input type="date" placeholder="DATE OF BIRTH" name="dob" required><br>
        
     <br><label for="doj"><b>Date Of Join</b></label><br>
    <input type="date" calss="form-control" placeholder="Date of join" name="doj" required><br>

     <br><label for="address"><b>Address</b></label><br>
    <input type="text" placeholder="address" name="address" required>
    
    <label for="mobile"><b>Mobile Number</b></label>
    <input type="text" placeholder="mobile" name="mobile" required>
    
    <label for="designation"><b>Designation</b></label>
     <input type="text" placeholder="designation" name="designation" required>

    <label for="name"><b>Bank Account Number</b></label>
    <input type="text" placeholder="Bank account" name="accountno" required>

    <label for="name"><b>Adhar card number</b></label>
    <input type="text" placeholder="adhar card number" name="adhar" required>
    
    <label for="name"><b>Pan number</b></label>
    <input type="text" placeholder="pan number" name="pan" required>

     

    <label for="deptid"><b>Depatment ID</b></label>

    

<select class="form-control" name="deptid" id="inputState">


<option selected>choose</option>
<?php 
    
    $data=mysqli_query($conn,$query);
    $cnt=1;

    while($result= mysqli_fetch_assoc($data)){

      ?>


<option ><?php echo $result['deptid']; ?></option>

<?php
  $cnt++;
}
    ?>

</select>
      <button type="submit" class="registerbtn">submit</button>
   </div>


  </form>
    


    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>

</html>