<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/login-register.css">
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">

	<script src="js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="js/bootstrap.js" type="text/javascript"></script>
	<script src="js/login-register.js" type="text/javascript"></script>
    <title>Document</title>
</head>
<style>body {
    margin: 0;
    padding: 0;
    background: #076585;  /* fallback for old browsers */
background: -webkit-linear-gradient(to top, #fff, #076585);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to bottom, #fff, #076585); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

}

h1 {
    margin: auto;
    list-style: none;
    font-size: 50px;
    font-weight: 100;
    color: #000;
}

.container-1 {
    display: flex;
    justify-content: space-around;
    flex-direction: column;
    height: 100vh;
}

.container-1 .homepageimg {
    height: 50%;
    width:50%;
    margin-left:25%;
    transform: translateY(-225px);
    
}</style>
<body>
    
    <div class="container-1" style="margin-top:-10px;">
            
        
            <nav>
                
 <div class="container" style="width:400px;">
       
         <div class="modal fade login" id="loginModal"  >
              <div class="modal-dialog login animated">
                  <div class="modal-content">
                     <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title"></h4>
                    </div>
                    <div class="modal-body" >
                        <div class="box">
                             <div class="content">
                              
                                <h1 style="color:#000;font-size:20px;margin-bottom:20%;margin-left:30%;">Admin- <span style=" color:rgb(66, 0, 128);font-weight: 700;"> login </span> </h1>
                               
                                <div class="error"></div>
                            
                                <div class="form loginBox">
                                    <form method="POST" action="index2.php" accept-charset="UTF-8">

                                    <input id="email" class="form-control" type="text" placeholder="username" name="username">

                                    <input id="password" class="form-control" type="password" placeholder="Password" name="password">


                                    <input class="btn btn-default btn-login" type="submit"  >

                                    </form>
                                </div>
                             </div>
                        </div>

                    </div>
                  
                  </div>
              </div>
          </div>
    </div>
            </nav>
        
            <h1 style="margin-bottom:10%;font-family:monospace">
                   Employee DataBase
                </h1>
                <img class="homepageimg"  src="Bs.png" alt="" >

                <div class="bttn">
                        <button class="btn  text-center" style="background: rgb(0, 0, 0);color:rgb(255, 255, 255); width:200px;margin-left:45%;margin-right:auto;transform:translateY(-190px);height: auto;" data-toggle="modal" onclick="openLoginModal();" type="button">Log in</button>
                      
                </div>
                
               
               <?php
                if($_SESSION['lo']=="wrong"){
                    $_SESSION['lo']="null";
                    echo "<script>alert('Credentials do not match');</script>";
                }
               ?>
                             
    </div>
   
        <script type="text/javascript">
            $(document).ready(function(){
                openLoginModal();
            });
        </script>
   
</body>
</html>