<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Employee Database</title>
    <style>{box-sizing: border-box}

/* Add padding to containers */
.container {
  padding: 15px;
  margin: 30px 0 10px 0;
    
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 20px;
  margin: 8px 0 12px 0;
  display: inline-block;
  border: none;
  font-family:monospace;
  background: #e6ecff;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit/register button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity:1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
.formcontainer{
    font-size:15px;
}

}
</style>
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
<!-- Bootstrap CSS CDN -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


</head>
<body>
<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Employee Database</h3>
                <strong>ED</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-user-circle"></i>
                        User
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="newuser.php">  New Employee</a>
                        </li>
                        <li>
                            <a href="viewuser1.php"> View Employee</a>
                        </li>
                        <li>
                            <a href="salary.php">Add Salary</a>
                        </li>
                    
                        <li>
                            <a href="viewsalary.php">View Salary</a>
                        </li>
                    
                    </ul>
                </li>
                <li>
                   
                    </a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-copy"></i>
                        Department
                    </a>
                     <ul class="collapse list-unstyled" id="pageSubmenu"> 
                        <li>
                            <a href="research.php">Research department</a>
                        </li>
                        <li>
                            <a href="resource.php">Marketing Department</a>
                        </li>
                        <li>
                            <a href="finance.php">Finance Department </a>
                        </li>
                    </ul>
                </li>
                <li>
                     <a href="searchicon.php">
                        <i class="fas fa-search"></i>
                        Search   
                    </a>
                </li> 
              
            </ul>

          
        </nav>

        <!-- Page Content  -->
            
        
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                       
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>

                      </nav>


  <div class="container" style="font-family:monospace">
    <h1>Add Salary Details</h1>
    <p>Fill the Details of Emmployee</p>
    <hr>
    <div class="formcontainer"> 
    <form action="salaryconnect.php" method="POST">
    <label for="empid"> <b>Employee ID</b></label>
    <input type="text" placeholder="Employee id" name="empid" required>
<!-- 
    <br><label for="etype"><b>Employee Type</b></label><br>
    <input type="text" placeholder="Employee type" name="etype" required><br>
     -->

    <label for="bsalary"><b>Basic Salary</b></label>
    <input type="text" placeholder="Basic Salary" name="bsalary" required>
    
    <!-- <label for="hra"><b>House Rent Allocation</b></label>
    <input type="text" placeholder="House Rent Allocation" name="hra" required> -->
    
    <!-- <label for="sa"><b>Special Allowance</b></label>
    <input type="text" placeholder="Special Allowance" name="sa" required> -->

    <label for="bonous"><b>Bonous</b></label>
    <input type="text" placeholder="Bonous" name="bonous" required>

    <!-- <label for="da"><b>Dearness Allowance</b></label><br>
    <input type="text" placeholder="Dearness Allowance" name="da" required><br> -->

     <br><label for="inscentive"><b>Inscentive</b></label><br>
    <input type="text" placeholder="Inscentive" name="inscentive" required><br>

    
    <br><label for="pfund"><b>Provident Fund</b></label><br>
    <input type="text" placeholder="Provident Fund" name="pfund" required><br>
    

    <br><label for="incometax"><b>Income Tax</b></label><br>
    <input type="text" placeholder="Income Tax" name="incometax" required><br>
    
    
    
    <button type="submit" class="registerbtn">submit</button>
   </div>


  </form>
  
  
    </div>
   

</body>
</html>