<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<style>
table {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

 td,  th {
  border: 1px solid #ddd;
  padding: 8px;
}

 tr:nth-child(even){background-color: #f2f2f2;}

tr:hover {background-color: #ddd;}

 th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
 }
  </style>
<body>

<div class="container">
  <h2>TOTAL EMPLOYEES</h2><br>    
       
  <table class="table table-">
    <thead>
      <tr>
        
        <th>Employee ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Employee Type</th>
        <th>Date of birth</th>
        <th>DAte of join</th>
        <th>Address</th>
        <th>Mobile Number</th>
        <th>Gender</th>
        <th>Designation</th>
        <th>Account Number</th>
        <th>Adhar Number</th>
        <th>Pan Number</th>
        <th>Department ID</th>
        <th>Update</th>
      </tr>
      </thead>
    
   
  

      <?php
$conn = mysqli_connect("localhost", "root", "", "employee");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * from employee ";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {


echo "<tr>
<td>" . $row["empid"]. "</td>
<td>" . $row["fname"] . "</td>
<td>". $row["lname"]. "</td>
<td>". $row["etype"]. "</td>
<td>". $row["dob"]. "</td>
<td>". $row["doj"]. "</td>
<td>". $row["address"]. "</td>
<td>". $row["mobile"]. "</td>
<td>". $row["gender"]. "</td>
<td>". $row["designation"]. "</td>
<td>". $row["accountno"]. "</td>
<td>". $row["adhar"]. "</td>
<td>". $row["pan"]. "</td>
<td>". $row["deptid"]. "</td>
<td><a href='update.php?emp=<?php$row[empid]?>'>update</a></td>

</tr>";

}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
    
    
  </table>


</body>
</html>
