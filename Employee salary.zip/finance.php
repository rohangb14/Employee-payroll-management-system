<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";
$conn = mysqli_connect($servername,$username,$password,$dbname );
error_reporting(0);
$query=" SELECT * FROM EMPLOYEE WHERE deptid=123 ";
$data=mysqli_query($conn,$query);
$total=mysqli_num_rows($data);



if($total !=0)
{
    
   
}else{

    echo '<script type="text/javascript"> alert(" no reecords"); </script>';
}


?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>View Employee</title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style5.css">

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
    <style>
     

        
        .col-sm-2{
        
        margin:20px;
        height:350px;
        width: 200px;;
        text-align: center;
        display: flex;
        justify-content: center;
            flex-direction: column;
        overflow: hidden;
        
        }
       

        
        .col-sm-2{
        
        margin:20px;
        height:350px;
        width: 200px;;
        text-align: center;
        display: flex;
        justify-content: center;
            flex-direction: column;
        overflow: hidden;
        
        }
       
       
       
    </style>
</head>

<body>

<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Employee Database</h3>
                <strong>ED</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-user-circle"></i>
                        User
                    </a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="newuser.php">  New Employee</a>
                        </li>
                        <li>
                            <a href="viewuser1.php"> View Employee</a>
                        </li>
                        <li>
                            <a href="salary.php">Add Salary</a>
                        </li>
                    
                        <li>
                            <a href="viewsalary.php">View Salary</a>
                        </li>
                    
                    </ul>
                </li>
                <li>
                   
                    </a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-copy"></i>
                        Department
                    </a>
                     <ul class="collapse list-unstyled" id="pageSubmenu"> 
                        <li>
                            <a href="research.php">Research department</a>
                        </li>
                        <li>
                            <a href="resource.php">Marketing Department</a>
                        </li>
                        <li>
                            <a href="finance.php">Finance Department </a>
                        </li>
                    </ul>
                </li>
                <li>
                     <a href="searchicon.php">
                        <i class="fas fa-search"></i>
                        Search   
                    </a>
                </li> 
              
            </ul>

          
        </nav>

        <!-- Page Content  -->
            
        
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                       
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>

                      </nav>
              

                

    <div class="wrapper d-flex justify-content-between" >
    <div id="content">
     <div class="container-fluid" align="center" style="margin-top:2%;">
                <h1>FINANCE DEPARTMENT EMPLOYEES</h1><br>
              
      
              </div>
      
              <table class="table table-stripped" style="width:80%;font-size:15px;font-weight:100; margin-left:10%;" >
        <thead>
        <tr>
        
        <th>Employee ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Department ID</th>
        
      </tr>
        </thead>
        <tbody>
          <tr>
              <?php
              $data=mysqli_query($conn,$query);
              $cnt=1;

              while( $result= mysqli_fetch_assoc($data)){

                ?>
  
            
            <td><?php  echo $result['empid'] ?></td>
            <td><?php  echo $result['fname'] ?></td>
            <td><?php  echo $result['lname']  ?></td>
        
            <td><?php  echo $result['deptid']  ?></td>

            <style>
            
               
                a :hover{

                    font-size:50px;
                    color:aqua;

                }
            
            </style>
         
            
          </tr>

          <?php

          $cnt++;
       
         } ?>
        </tbody>
              </table>

             </div>

      
    </div>


    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $(this).toggleClass('active');
            });
        });
    </script>
</body>

</html>