<?php
session_start();
 if($_POST['username']=="admin" && $_POST['password']=="admin"){
        $_SESSION['lod2']=1;
        $_SESSION['lod']="in";
        header("Location: index.php");
 }
else {
    echo "<script>alert('Credentials do not match');</script>";
    $_SESSION['lo']="wrong";
    header("Location: homepage.php");
}
  ?>