<?php 
$servername="localhost";
$username="root";
$password="";
$dbname="medicalhandbook";

$conn = new mysqli($servername,$username,$password,$dbname);
if($conn)
{
  echo "";
}
// php code to search data in mysql database and set it in input text
if(isset($_POST['disease']))
{
    // id to search
    $diseaseq = $_POST['disease'];
    
    // connect to mysql
    //$connect = mysqli_connect("localhost", "root", "","medicalhandbook");
    echo $diseaseq;
    // mysql search query
    $query=("SELECT m.medicine_name,m.composition,h.food_avoided,h.diet,s.symptom_name,de.infectant,de.description,sp.specialist_name, sp.clinic_name,sp.phone_no FROM disease d,medical_composition m,health_tips h,symptoms s,descriptions de,specialist sp WHERE d.disease_name like '%$diseaseq%' and d.disease_id=h.disease_id and m.medicine_id=d.medicine_id and s.symptom_id=d.symptom_id and d.disease_id=de.disease_id and d.disease_id=sp.disease_id");
    $result = mysqli_query($conn, $query);
    $count=mysqli_num_rows($result);
    if($count==0)
    {    
         $op="no result";
    }
    else
    {
        while ($rows = mysqli_fetch_array($result))
      {
         
         $d2=$rows['medicine_name'];
          $d3=$rows['composition'];
          $d4=$rows['food_avoided'];
          $d5=$rows['diet'];
          $d6=$rows['symptom_name'];
          $d7=$rows['infectant'];
          $d8=$rows['specialist_name'];
          $d9=$rows['clinic_name'];
          $d10=$rows['phone_no'];
          $d11=$rows['description'];
          $op .='<div> '.$d2.' '.$d3.' '.$d4.' '.$d5.' '.$d6.' '.$d7.' '.$d8.' '.$d9.' '.$d10.' '.$d11.' </div>';
        
      }
      
      
    }
    
    ?>
 















 SELECT e.empid,e.fname,e.lname,s.hra,s.sa,s.bonous,s.da,s.inscentive,s.tsalary,d.pfund,d.incometax,d.ar,d.ptax from employee e,salary s,deduction d where e.empid like "% $empid"