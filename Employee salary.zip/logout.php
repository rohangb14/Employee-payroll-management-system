<?php
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "employee";
// $conn = mysqli_connect($servername,$username,$password,$dbname );

// if(isset($_GET['logout'])) { 

//session_start();
// session_destroy();
session_start();
$_SESSION['lod']="out";
header('Location: homepage.php');

//}
?>