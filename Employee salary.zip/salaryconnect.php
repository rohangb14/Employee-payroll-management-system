<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";
$id = $_POST['empid'];
$bsalary = $_POST['bsalary'];
$hra = 2000;
$sa = 3500;
$bonous = $_POST['bonous'];
$da = 3000;
$inscentive = $_POST['inscentive'];
$pfund=$_POST['pfund'];
$incometax=$_POST['incometax'];
$ar=1000;
$ptax=2000;

$tsalary = $bsalary+$hra+$sa+$bonous+$da+$inscentive;
// $netpay= $tsalary/28 ;
$tdeduction=$pfund+$incometax+$ar+$ptax;

//create connection

$conn = new mysqli($servername,$username,$password,$dbname );


//check connection

if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//insert into table
$sql = "INSERT INTO salary(empid,bsalary,hra,sa,bonous,da,inscentive,tsalary) VALUES ('$id','$bsalary','$hra','$sa','$bonous','$da','$inscentive','$tsalary')";
$query=mysqli_query($conn,$sql) or die (mysqli_error($conn));

if($query==1){

	$sql1="INSERT INTO deduction(empid,pfund,incometax) VALUES ('$id','$pfund','$incometax')";
	$query1=mysqli_query($conn,$sql1);

	$sql2="update deduction set ar='$ar' where empid='$id'";
	$query2=mysqli_query($conn,$sql2);

	$sql2="update deduction set ptax='$ptax' where empid='$id'";
	$query2=mysqli_query($conn,$sql2);

	$sql2="update deduction set tdeduction='$tdeduction' where empid='$id'";
	$query3=mysqli_query($conn,$sql2);

	
	$sql4 = "select tsalary from salary where empid='$id'";
	$query4 = mysqli_query($conn, $sql4);
	$q4 = mysqli_fetch_array($query4);
	$fsal = $q4['0'] - $tdeduction;
	
	$sql5 = "update deduction set finalsalary='$fsal' where empid='$id'";
	$query5 = mysqli_query($conn, $sql5);
	
}





if($conn->query($sql) === TRUE)
{
	 $last_id = $conn->insert_id;
	echo '<script type="text/javascript"> alert(" SUCESSFULLY ENTERED.."); </script>';
}
else
{
	echo "Error:" . $sql . "<br>" . $conn->error;
}header("refresh:2; url=index.php"); // url for wherever you want to direct it ! after login 
 //echo '<a href="index.php" ><button style="width:50px;height:50px;">View</button></a>';
?>
