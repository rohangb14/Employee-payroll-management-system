<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee";
$empid=$_GET['empid'];
$conn = mysqli_connect($servername,$username,$password,$dbname );

$query= " DELETE FROM employee WHERE empid='$empid';";

$data = mysqli_query($conn,$query);
 
if($data)
{
    echo '<script type="text/javascript"> alert("Deleted !!!"); </script>';
}else{


    echo '<script type="text/javascript"> alert(" no reecords"); </script>';
}
header("Location:viewuser1.php")
?>